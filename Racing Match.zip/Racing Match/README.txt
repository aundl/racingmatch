Hallo!
Danke, dass du RACING MATCH von A&L Technologies installiert hast. Dies ist ein Spiel in der ALPHA-Version, was heißt, dass es viele Bugs enthält.

Bitte klicke auf initiate.bat um alle Schritte zu erledigen um diese Datei auszuführen. Danach solltest du das Spiel normal öffnen können oder direkt die RacingMatch.exe öffnen kannst! Bitte öffne diese Datei jedoch mit Python 3.10. Andere Versionen werden nicht unterstützt.

Danke, dass du spielst! :)


Viele Grüße,
das A&L Technologies Team.


- - - - Falls du Hilfe brauchst, schreibe den Support an unter "support.aundl.tech". - - - -